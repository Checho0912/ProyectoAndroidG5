package com.mycompany.proyectofinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
