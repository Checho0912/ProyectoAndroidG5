import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBe4RbnXRiYa8BVfR57I-B64bqDeibaIb8",
            authDomain: "proyecto-final-hho8n2.firebaseapp.com",
            projectId: "proyecto-final-hho8n2",
            storageBucket: "proyecto-final-hho8n2.firebasestorage.app",
            messagingSenderId: "299672464453",
            appId: "1:299672464453:web:813b0f2bc0d3322893472c"));
  } else {
    await Firebase.initializeApp();
  }
}
