import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LugaresRecord extends FirestoreRecord {
  LugaresRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "destino_id" field.
  int? _destinoId;
  int get destinoId => _destinoId ?? 0;
  bool hasDestinoId() => _destinoId != null;

  // "nombre_destino" field.
  String? _nombreDestino;
  String get nombreDestino => _nombreDestino ?? '';
  bool hasNombreDestino() => _nombreDestino != null;

  // "descripcion_destino" field.
  String? _descripcionDestino;
  String get descripcionDestino => _descripcionDestino ?? '';
  bool hasDescripcionDestino() => _descripcionDestino != null;

  // "ubicacion_destino" field.
  String? _ubicacionDestino;
  String get ubicacionDestino => _ubicacionDestino ?? '';
  bool hasUbicacionDestino() => _ubicacionDestino != null;

  // "horario" field.
  String? _horario;
  String get horario => _horario ?? '';
  bool hasHorario() => _horario != null;

  // "categoria" field.
  String? _categoria;
  String get categoria => _categoria ?? '';
  bool hasCategoria() => _categoria != null;

  // "telefono" field.
  String? _telefono;
  String get telefono => _telefono ?? '';
  bool hasTelefono() => _telefono != null;

  // "calificacion_destino" field.
  double? _calificacionDestino;
  double get calificacionDestino => _calificacionDestino ?? 0.0;
  bool hasCalificacionDestino() => _calificacionDestino != null;

  // "imagen_url" field.
  String? _imagenUrl;
  String get imagenUrl => _imagenUrl ?? '';
  bool hasImagenUrl() => _imagenUrl != null;

  void _initializeFields() {
    _destinoId = castToType<int>(snapshotData['destino_id']);
    _nombreDestino = snapshotData['nombre_destino'] as String?;
    _descripcionDestino = snapshotData['descripcion_destino'] as String?;
    _ubicacionDestino = snapshotData['ubicacion_destino'] as String?;
    _horario = snapshotData['horario'] as String?;
    _categoria = snapshotData['categoria'] as String?;
    _telefono = snapshotData['telefono'] as String?;
    _calificacionDestino =
        castToType<double>(snapshotData['calificacion_destino']);
    _imagenUrl = snapshotData['imagen_url'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Lugares');

  static Stream<LugaresRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => LugaresRecord.fromSnapshot(s));

  static Future<LugaresRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => LugaresRecord.fromSnapshot(s));

  static LugaresRecord fromSnapshot(DocumentSnapshot snapshot) =>
      LugaresRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static LugaresRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      LugaresRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'LugaresRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is LugaresRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createLugaresRecordData({
  int? destinoId,
  String? nombreDestino,
  String? descripcionDestino,
  String? ubicacionDestino,
  String? horario,
  String? categoria,
  String? telefono,
  double? calificacionDestino,
  String? imagenUrl,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'destino_id': destinoId,
      'nombre_destino': nombreDestino,
      'descripcion_destino': descripcionDestino,
      'ubicacion_destino': ubicacionDestino,
      'horario': horario,
      'categoria': categoria,
      'telefono': telefono,
      'calificacion_destino': calificacionDestino,
      'imagen_url': imagenUrl,
    }.withoutNulls,
  );

  return firestoreData;
}

class LugaresRecordDocumentEquality implements Equality<LugaresRecord> {
  const LugaresRecordDocumentEquality();

  @override
  bool equals(LugaresRecord? e1, LugaresRecord? e2) {
    return e1?.destinoId == e2?.destinoId &&
        e1?.nombreDestino == e2?.nombreDestino &&
        e1?.descripcionDestino == e2?.descripcionDestino &&
        e1?.ubicacionDestino == e2?.ubicacionDestino &&
        e1?.horario == e2?.horario &&
        e1?.categoria == e2?.categoria &&
        e1?.telefono == e2?.telefono &&
        e1?.calificacionDestino == e2?.calificacionDestino &&
        e1?.imagenUrl == e2?.imagenUrl;
  }

  @override
  int hash(LugaresRecord? e) => const ListEquality().hash([
        e?.destinoId,
        e?.nombreDestino,
        e?.descripcionDestino,
        e?.ubicacionDestino,
        e?.horario,
        e?.categoria,
        e?.telefono,
        e?.calificacionDestino,
        e?.imagenUrl
      ]);

  @override
  bool isValidKey(Object? o) => o is LugaresRecord;
}
