// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

/// Objeto para los lugares
class LugarStruct extends FFFirebaseStruct {
  LugarStruct({
    int? destinoId,
    String? nombreDestino,
    String? descripcionDestino,
    String? ubicacionDestino,

    /// Para poder filtrar los destinos
    String? categoriaDestino,
    String? telefonoDestino,
    double? calificacionDestino,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _destinoId = destinoId,
        _nombreDestino = nombreDestino,
        _descripcionDestino = descripcionDestino,
        _ubicacionDestino = ubicacionDestino,
        _categoriaDestino = categoriaDestino,
        _telefonoDestino = telefonoDestino,
        _calificacionDestino = calificacionDestino,
        super(firestoreUtilData);

  // "destino_id" field.
  int? _destinoId;
  int get destinoId => _destinoId ?? 0;
  set destinoId(int? val) => _destinoId = val;

  void incrementDestinoId(int amount) => destinoId = destinoId + amount;

  bool hasDestinoId() => _destinoId != null;

  // "nombre_destino" field.
  String? _nombreDestino;
  String get nombreDestino => _nombreDestino ?? '';
  set nombreDestino(String? val) => _nombreDestino = val;

  bool hasNombreDestino() => _nombreDestino != null;

  // "descripcion_destino" field.
  String? _descripcionDestino;
  String get descripcionDestino => _descripcionDestino ?? '';
  set descripcionDestino(String? val) => _descripcionDestino = val;

  bool hasDescripcionDestino() => _descripcionDestino != null;

  // "ubicacion_destino" field.
  String? _ubicacionDestino;
  String get ubicacionDestino => _ubicacionDestino ?? '';
  set ubicacionDestino(String? val) => _ubicacionDestino = val;

  bool hasUbicacionDestino() => _ubicacionDestino != null;

  // "categoria_destino" field.
  String? _categoriaDestino;
  String get categoriaDestino => _categoriaDestino ?? '';
  set categoriaDestino(String? val) => _categoriaDestino = val;

  bool hasCategoriaDestino() => _categoriaDestino != null;

  // "telefono_destino" field.
  String? _telefonoDestino;
  String get telefonoDestino => _telefonoDestino ?? '';
  set telefonoDestino(String? val) => _telefonoDestino = val;

  bool hasTelefonoDestino() => _telefonoDestino != null;

  // "calificacion_destino" field.
  double? _calificacionDestino;
  double get calificacionDestino => _calificacionDestino ?? 0.0;
  set calificacionDestino(double? val) => _calificacionDestino = val;

  void incrementCalificacionDestino(double amount) =>
      calificacionDestino = calificacionDestino + amount;

  bool hasCalificacionDestino() => _calificacionDestino != null;

  static LugarStruct fromMap(Map<String, dynamic> data) => LugarStruct(
        destinoId: castToType<int>(data['destino_id']),
        nombreDestino: data['nombre_destino'] as String?,
        descripcionDestino: data['descripcion_destino'] as String?,
        ubicacionDestino: data['ubicacion_destino'] as String?,
        categoriaDestino: data['categoria_destino'] as String?,
        telefonoDestino: data['telefono_destino'] as String?,
        calificacionDestino: castToType<double>(data['calificacion_destino']),
      );

  static LugarStruct? maybeFromMap(dynamic data) =>
      data is Map ? LugarStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'destino_id': _destinoId,
        'nombre_destino': _nombreDestino,
        'descripcion_destino': _descripcionDestino,
        'ubicacion_destino': _ubicacionDestino,
        'categoria_destino': _categoriaDestino,
        'telefono_destino': _telefonoDestino,
        'calificacion_destino': _calificacionDestino,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'destino_id': serializeParam(
          _destinoId,
          ParamType.int,
        ),
        'nombre_destino': serializeParam(
          _nombreDestino,
          ParamType.String,
        ),
        'descripcion_destino': serializeParam(
          _descripcionDestino,
          ParamType.String,
        ),
        'ubicacion_destino': serializeParam(
          _ubicacionDestino,
          ParamType.String,
        ),
        'categoria_destino': serializeParam(
          _categoriaDestino,
          ParamType.String,
        ),
        'telefono_destino': serializeParam(
          _telefonoDestino,
          ParamType.String,
        ),
        'calificacion_destino': serializeParam(
          _calificacionDestino,
          ParamType.double,
        ),
      }.withoutNulls;

  static LugarStruct fromSerializableMap(Map<String, dynamic> data) =>
      LugarStruct(
        destinoId: deserializeParam(
          data['destino_id'],
          ParamType.int,
          false,
        ),
        nombreDestino: deserializeParam(
          data['nombre_destino'],
          ParamType.String,
          false,
        ),
        descripcionDestino: deserializeParam(
          data['descripcion_destino'],
          ParamType.String,
          false,
        ),
        ubicacionDestino: deserializeParam(
          data['ubicacion_destino'],
          ParamType.String,
          false,
        ),
        categoriaDestino: deserializeParam(
          data['categoria_destino'],
          ParamType.String,
          false,
        ),
        telefonoDestino: deserializeParam(
          data['telefono_destino'],
          ParamType.String,
          false,
        ),
        calificacionDestino: deserializeParam(
          data['calificacion_destino'],
          ParamType.double,
          false,
        ),
      );

  @override
  String toString() => 'LugarStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is LugarStruct &&
        destinoId == other.destinoId &&
        nombreDestino == other.nombreDestino &&
        descripcionDestino == other.descripcionDestino &&
        ubicacionDestino == other.ubicacionDestino &&
        categoriaDestino == other.categoriaDestino &&
        telefonoDestino == other.telefonoDestino &&
        calificacionDestino == other.calificacionDestino;
  }

  @override
  int get hashCode => const ListEquality().hash([
        destinoId,
        nombreDestino,
        descripcionDestino,
        ubicacionDestino,
        categoriaDestino,
        telefonoDestino,
        calificacionDestino
      ]);
}

LugarStruct createLugarStruct({
  int? destinoId,
  String? nombreDestino,
  String? descripcionDestino,
  String? ubicacionDestino,
  String? categoriaDestino,
  String? telefonoDestino,
  double? calificacionDestino,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    LugarStruct(
      destinoId: destinoId,
      nombreDestino: nombreDestino,
      descripcionDestino: descripcionDestino,
      ubicacionDestino: ubicacionDestino,
      categoriaDestino: categoriaDestino,
      telefonoDestino: telefonoDestino,
      calificacionDestino: calificacionDestino,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

LugarStruct? updateLugarStruct(
  LugarStruct? lugar, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    lugar
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addLugarStructData(
  Map<String, dynamic> firestoreData,
  LugarStruct? lugar,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (lugar == null) {
    return;
  }
  if (lugar.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && lugar.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final lugarData = getLugarFirestoreData(lugar, forFieldValue);
  final nestedData = lugarData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = lugar.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getLugarFirestoreData(
  LugarStruct? lugar, [
  bool forFieldValue = false,
]) {
  if (lugar == null) {
    return {};
  }
  final firestoreData = mapToFirestore(lugar.toMap());

  // Add any Firestore field values
  lugar.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getLugarListFirestoreData(
  List<LugarStruct>? lugars,
) =>
    lugars?.map((e) => getLugarFirestoreData(e, true)).toList() ?? [];
