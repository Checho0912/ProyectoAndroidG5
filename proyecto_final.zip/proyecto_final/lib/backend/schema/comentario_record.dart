import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ComentarioRecord extends FirestoreRecord {
  ComentarioRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "texto" field.
  String? _texto;
  String get texto => _texto ?? '';
  bool hasTexto() => _texto != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _texto = snapshotData['texto'] as String?;
    _user = snapshotData['user'] as DocumentReference?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Comentario')
          : FirebaseFirestore.instance.collectionGroup('Comentario');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Comentario').doc(id);

  static Stream<ComentarioRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ComentarioRecord.fromSnapshot(s));

  static Future<ComentarioRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ComentarioRecord.fromSnapshot(s));

  static ComentarioRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ComentarioRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ComentarioRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ComentarioRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ComentarioRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ComentarioRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createComentarioRecordData({
  String? texto,
  DocumentReference? user,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'texto': texto,
      'user': user,
    }.withoutNulls,
  );

  return firestoreData;
}

class ComentarioRecordDocumentEquality implements Equality<ComentarioRecord> {
  const ComentarioRecordDocumentEquality();

  @override
  bool equals(ComentarioRecord? e1, ComentarioRecord? e2) {
    return e1?.texto == e2?.texto && e1?.user == e2?.user;
  }

  @override
  int hash(ComentarioRecord? e) =>
      const ListEquality().hash([e?.texto, e?.user]);

  @override
  bool isValidKey(Object? o) => o is ComentarioRecord;
}
