import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PostRecord extends FirestoreRecord {
  PostRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "postFoto" field.
  String? _postFoto;
  String get postFoto => _postFoto ?? '';
  bool hasPostFoto() => _postFoto != null;

  // "postTitulo" field.
  String? _postTitulo;
  String get postTitulo => _postTitulo ?? '';
  bool hasPostTitulo() => _postTitulo != null;

  // "postDescripcion" field.
  String? _postDescripcion;
  String get postDescripcion => _postDescripcion ?? '';
  bool hasPostDescripcion() => _postDescripcion != null;

  // "postUser" field.
  DocumentReference? _postUser;
  DocumentReference? get postUser => _postUser;
  bool hasPostUser() => _postUser != null;

  // "postPublicaionTiempo" field.
  DateTime? _postPublicaionTiempo;
  DateTime? get postPublicaionTiempo => _postPublicaionTiempo;
  bool hasPostPublicaionTiempo() => _postPublicaionTiempo != null;

  // "numComentarios" field.
  int? _numComentarios;
  int get numComentarios => _numComentarios ?? 0;
  bool hasNumComentarios() => _numComentarios != null;

  void _initializeFields() {
    _postFoto = snapshotData['postFoto'] as String?;
    _postTitulo = snapshotData['postTitulo'] as String?;
    _postDescripcion = snapshotData['postDescripcion'] as String?;
    _postUser = snapshotData['postUser'] as DocumentReference?;
    _postPublicaionTiempo = snapshotData['postPublicaionTiempo'] as DateTime?;
    _numComentarios = castToType<int>(snapshotData['numComentarios']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('post');

  static Stream<PostRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PostRecord.fromSnapshot(s));

  static Future<PostRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PostRecord.fromSnapshot(s));

  static PostRecord fromSnapshot(DocumentSnapshot snapshot) => PostRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PostRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PostRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PostRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PostRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPostRecordData({
  String? postFoto,
  String? postTitulo,
  String? postDescripcion,
  DocumentReference? postUser,
  DateTime? postPublicaionTiempo,
  int? numComentarios,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'postFoto': postFoto,
      'postTitulo': postTitulo,
      'postDescripcion': postDescripcion,
      'postUser': postUser,
      'postPublicaionTiempo': postPublicaionTiempo,
      'numComentarios': numComentarios,
    }.withoutNulls,
  );

  return firestoreData;
}

class PostRecordDocumentEquality implements Equality<PostRecord> {
  const PostRecordDocumentEquality();

  @override
  bool equals(PostRecord? e1, PostRecord? e2) {
    return e1?.postFoto == e2?.postFoto &&
        e1?.postTitulo == e2?.postTitulo &&
        e1?.postDescripcion == e2?.postDescripcion &&
        e1?.postUser == e2?.postUser &&
        e1?.postPublicaionTiempo == e2?.postPublicaionTiempo &&
        e1?.numComentarios == e2?.numComentarios;
  }

  @override
  int hash(PostRecord? e) => const ListEquality().hash([
        e?.postFoto,
        e?.postTitulo,
        e?.postDescripcion,
        e?.postUser,
        e?.postPublicaionTiempo,
        e?.numComentarios
      ]);

  @override
  bool isValidKey(Object? o) => o is PostRecord;
}
