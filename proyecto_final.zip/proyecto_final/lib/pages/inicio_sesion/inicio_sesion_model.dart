import '/auth/custom_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'inicio_sesion_widget.dart' show InicioSesionWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class InicioSesionModel extends FlutterFlowModel<InicioSesionWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for CorreoTextField widget.
  FocusNode? correoTextFieldFocusNode;
  TextEditingController? correoTextFieldTextController;
  String? Function(BuildContext, String?)?
      correoTextFieldTextControllerValidator;
  // State field(s) for ContrasennaTextField widget.
  FocusNode? contrasennaTextFieldFocusNode;
  TextEditingController? contrasennaTextFieldTextController;
  late bool contrasennaTextFieldVisibility;
  String? Function(BuildContext, String?)?
      contrasennaTextFieldTextControllerValidator;
  // Stores action output result for [Custom Action - encryptData] action in Button widget.
  String? encryptedPassword;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UserRecord? user;
  // Stores action output result for [Backend Call - API (Create JWT)] action in Button widget.
  ApiCallResponse? jwt;

  @override
  void initState(BuildContext context) {
    contrasennaTextFieldVisibility = false;
  }

  @override
  void dispose() {
    correoTextFieldFocusNode?.dispose();
    correoTextFieldTextController?.dispose();

    contrasennaTextFieldFocusNode?.dispose();
    contrasennaTextFieldTextController?.dispose();
  }
}
