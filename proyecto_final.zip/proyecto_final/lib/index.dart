// Export pages
export '/pages/inicio_sesion/inicio_sesion_widget.dart' show InicioSesionWidget;
export '/perfil_page/perfil_page_widget.dart' show PerfilPageWidget;
export '/favoritos_page/favoritos_page_widget.dart' show FavoritosPageWidget;
export '/pages/registro_de_usuario/registro_de_usuario_widget.dart'
    show RegistroDeUsuarioWidget;
export '/pagina_principal_prototipo/pagina_principal_prototipo_widget.dart'
    show PaginaPrincipalPrototipoWidget;
export '/destino_detallado/destino_detallado_widget.dart'
    show DestinoDetalladoWidget;
export '/paginade_contacto/paginade_contacto_widget.dart'
    show PaginadeContactoWidget;
export '/ev_turistico/ev_turistico_widget.dart' show EvTuristicoWidget;
export '/pagina_principal_busqueda/pagina_principal_busqueda_widget.dart'
    show PaginaPrincipalBusquedaWidget;
