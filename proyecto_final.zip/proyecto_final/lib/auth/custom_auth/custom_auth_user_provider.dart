import 'package:rxdart/rxdart.dart';

import 'custom_auth_manager.dart';

class ProyectoFinalAuthUser {
  ProyectoFinalAuthUser({required this.loggedIn, this.uid});

  bool loggedIn;
  String? uid;
}

/// Generates a stream of the authenticated user.
BehaviorSubject<ProyectoFinalAuthUser> proyectoFinalAuthUserSubject =
    BehaviorSubject.seeded(ProyectoFinalAuthUser(loggedIn: false));
Stream<ProyectoFinalAuthUser> proyectoFinalAuthUserStream() =>
    proyectoFinalAuthUserSubject
        .asBroadcastStream()
        .map((user) => currentUser = user);
